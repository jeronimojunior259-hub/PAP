export interface User {
  id: string;
  name: string;
  email: string;
  schoolYear: string; // e.g., "10º Ano"
  avatarUrl?: string;
}

export type GradeType = 'Teste' | 'Trabalho' | 'Exame' | 'Oral';

export interface Grade {
  id: string;
  subject: string;
  type: GradeType;
  date: string;
  value: number; // 0 to 20
  notes?: string;
}

export interface SubjectStats {
  name: string;
  average: number;
  count: number;
}
