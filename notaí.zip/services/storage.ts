import { Grade, User } from '../types';

const USERS_KEY = 'notai_users';
const CURRENT_USER_KEY = 'notai_current_user';
const GRADES_KEY = 'notai_grades_'; // Prefix with user ID

export const storageService = {
  // User Management
  saveUser: (user: User): void => {
    const users = storageService.getUsers();
    const existing = users.findIndex(u => u.email === user.email);
    if (existing >= 0) {
      users[existing] = user;
    } else {
      users.push(user);
    }
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  },

  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_KEY);
    return data ? JSON.parse(data) : [];
  },

  login: (email: string): User | null => {
    const users = storageService.getUsers();
    const user = users.find(u => u.email === email);
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
      return user;
    }
    return null;
  },

  logout: (): void => {
    localStorage.removeItem(CURRENT_USER_KEY);
  },

  getCurrentUser: (): User | null => {
    const data = localStorage.getItem(CURRENT_USER_KEY);
    return data ? JSON.parse(data) : null;
  },

  // Grade Management
  getGrades: (userId: string): Grade[] => {
    const data = localStorage.getItem(GRADES_KEY + userId);
    if (!data) {
      // Return some mock data for demo purposes if empty
      const mockGrades: Grade[] = [
        { id: '1', subject: 'Matemática', type: 'Teste', date: '2023-10-15', value: 14 },
        { id: '2', subject: 'Português', type: 'Trabalho', date: '2023-10-20', value: 16 },
        { id: '3', subject: 'Inglês', type: 'Teste', date: '2023-11-05', value: 18 },
        { id: '4', subject: 'Matemática', type: 'Teste', date: '2023-11-20', value: 12 },
        { id: '5', subject: 'Física-Química', type: 'Exame', date: '2023-12-10', value: 15 },
      ];
      localStorage.setItem(GRADES_KEY + userId, JSON.stringify(mockGrades));
      return mockGrades;
    }
    return JSON.parse(data);
  },

  saveGrade: (userId: string, grade: Grade): void => {
    const grades = storageService.getGrades(userId);
    const index = grades.findIndex(g => g.id === grade.id);
    if (index >= 0) {
      grades[index] = grade;
    } else {
      grades.push(grade);
    }
    localStorage.setItem(GRADES_KEY + userId, JSON.stringify(grades));
  },

  deleteGrade: (userId: string, gradeId: string): void => {
    const grades = storageService.getGrades(userId);
    const newGrades = grades.filter(g => g.id !== gradeId);
    localStorage.setItem(GRADES_KEY + userId, JSON.stringify(newGrades));
  }
};
