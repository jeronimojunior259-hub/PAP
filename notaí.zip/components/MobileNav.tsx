import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, GraduationCap, BarChart3, User } from 'lucide-react';

export const MobileNav = () => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Dash', path: '/dashboard' },
    { icon: GraduationCap, label: 'Notas', path: '/grades' },
    { icon: BarChart3, label: 'Relatórios', path: '/reports' },
    { icon: User, label: 'Perfil', path: '/profile' },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 px-6 py-3 flex justify-between items-center shadow-[0_-2px_10px_rgba(0,0,0,0.05)]">
      {navItems.map((item) => (
        <NavLink
          key={item.path}
          to={item.path}
          className={({ isActive }) =>
            `flex flex-col items-center gap-1 transition-colors ${
              isActive ? 'text-primary' : 'text-gray-400'
            }`
          }
        >
          <item.icon size={24} />
          <span className="text-xs font-medium">{item.label}</span>
        </NavLink>
      ))}
    </nav>
  );
};
