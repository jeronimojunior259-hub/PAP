import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Grade } from '../types';
import { storageService } from '../services/storage';

interface AppContextType {
  user: User | null;
  isAuthenticated: boolean;
  grades: Grade[];
  login: (email: string, name: string) => void;
  logout: () => void;
  addGrade: (grade: Omit<Grade, 'id'>) => void;
  removeGrade: (id: string) => void;
  isLoading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children?: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [grades, setGrades] = useState<Grade[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initial load
  useEffect(() => {
    const currentUser = storageService.getCurrentUser();
    if (currentUser) {
      setUser(currentUser);
      setGrades(storageService.getGrades(currentUser.id));
    }
    setIsLoading(false);
  }, []);

  const login = (email: string, name: string) => {
    setIsLoading(true);
    // Simulation of authentication
    setTimeout(() => {
      let foundUser = storageService.login(email);
      if (!foundUser) {
        // Auto-register for demo purposes
        const newUser: User = {
          id: Date.now().toString(),
          name,
          email,
          schoolYear: '10º Ano',
          avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=673AB7&color=fff`
        };
        storageService.saveUser(newUser);
        foundUser = storageService.login(email);
      }
      
      if (foundUser) {
        setUser(foundUser);
        setGrades(storageService.getGrades(foundUser.id));
      }
      setIsLoading(false);
    }, 800);
  };

  const logout = () => {
    storageService.logout();
    setUser(null);
    setGrades([]);
  };

  const addGrade = (gradeData: Omit<Grade, 'id'>) => {
    if (!user) return;
    const newGrade: Grade = {
      ...gradeData,
      id: Date.now().toString(),
    };
    storageService.saveGrade(user.id, newGrade);
    setGrades(prev => [...prev, newGrade]);
  };

  const removeGrade = (id: string) => {
    if (!user) return;
    storageService.deleteGrade(user.id, id);
    setGrades(prev => prev.filter(g => g.id !== id));
  };

  return (
    <AppContext.Provider value={{ 
      user, 
      isAuthenticated: !!user, 
      grades, 
      login, 
      logout, 
      addGrade, 
      removeGrade,
      isLoading 
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};