import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart2, ShieldCheck, ArrowRight, CheckCircle2, Star } from 'lucide-react';

export const Landing = () => {
  return (
    <div className="min-h-screen flex flex-col bg-white">
      {/* Navbar */}
      <header className="fixed w-full bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
        <div className="container mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Notaí" className="h-10 md:h-12 w-auto object-contain" />
          </div>
          <div className="flex items-center gap-6">
            <nav className="hidden md:flex gap-6 text-sm font-medium text-gray-600">
              <a href="#features" className="hover:text-primary transition-colors">Funcionalidades</a>
              <a href="#about" className="hover:text-primary transition-colors">Sobre</a>
              <a href="#testimonials" className="hover:text-primary transition-colors">Testemunhos</a>
            </nav>
            <Link to="/auth" className="px-5 py-2.5 bg-primary hover:bg-primary/90 text-white rounded-full font-medium transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
              Entrar
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-b from-purple-50 to-white">
        <div className="container mx-auto text-center max-w-4xl">
          <div className="inline-block px-4 py-1.5 bg-primary/10 text-primary rounded-full text-sm font-semibold mb-6 animate-pulse">
            🚀 A tua evolução escolar em tempo real
          </div>
          <h1 className="text-4xl md:text-6xl font-heading font-bold text-gray-900 leading-tight mb-6">
            Consulta notas, acompanha médias e <span className="text-primary">progride com clareza.</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed">
            Uma plataforma desenhada exclusivamente para alunos do secundário. Assume o controlo do teu desempenho escolar de forma simples, privada e visual.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/auth" className="w-full sm:w-auto px-8 py-4 bg-primary text-white text-lg font-semibold rounded-2xl shadow-xl shadow-primary/30 hover:shadow-2xl hover:shadow-primary/40 hover:-translate-y-1 transition-all flex items-center justify-center gap-2">
              Começar Agora <ArrowRight size={20} />
            </Link>
            <a href="#about" className="w-full sm:w-auto px-8 py-4 bg-white text-gray-700 border border-gray-200 text-lg font-semibold rounded-2xl hover:bg-gray-50 transition-all flex items-center justify-center">
              Saber mais
            </a>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-6">
        <div className="container mx-auto">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-center mb-16">
            Tudo o que precisas para o <span className="text-secondary">sucesso</span>
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: CheckCircle2, title: 'Consulta de Notas', desc: 'Regista todas as tuas notas de testes, trabalhos e exames num só lugar.' },
              { icon: BarChart2, title: 'Cálculo de Médias', desc: 'Cálculos automáticos de médias por disciplina e média final de curso.' },
              { icon: ArrowRight, title: 'Gráficos de Progresso', desc: 'Visualiza a tua evolução ao longo do ano letivo com gráficos intuitivos.' },
              { icon: ShieldCheck, title: '100% Privado', desc: 'Os teus dados são apenas teus. Acesso seguro e individual.' },
            ].map((feature, i) => (
              <div key={i} className="p-8 rounded-3xl border border-gray-100 bg-white hover:border-primary/20 hover:shadow-xl hover:shadow-primary/5 transition-all group">
                <div className="w-14 h-14 bg-blue-50 text-info rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-colors">
                  <feature.icon size={28} />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-500 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6 bg-background">
        <div className="container mx-auto max-w-5xl">
          <div className="bg-primary rounded-[3rem] p-8 md:p-16 text-white text-center md:text-left relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            <div className="relative z-10 flex flex-col md:flex-row items-center gap-12">
              <div className="flex-1 space-y-6">
                <h2 className="text-3xl md:text-4xl font-heading font-bold">Sobre o Notaí</h2>
                <p className="text-purple-100 text-lg leading-relaxed">
                  O Notaí é uma plataforma web educativa criada exclusivamente para alunos do ensino secundário, com o objetivo de oferecer uma forma intuitiva e privada de acompanhar o seu desempenho escolar. 
                </p>
                <p className="text-purple-100 text-lg leading-relaxed">
                  Valorizamos a autonomia, clareza e motivação, permitindo a cada estudante assumir o controlo da sua vida académica.
                </p>
              </div>
              <div className="flex-1 flex justify-center">
                <div className="bg-white/10 backdrop-blur-sm p-8 rounded-3xl border border-white/20">
                  <div className="flex flex-col gap-4">
                     <div className="flex items-center gap-4 text-white">
                        <div className="p-2 bg-secondary rounded-full"><CheckCircle2 size={20} /></div>
                        <span className="font-medium">Organização Simples</span>
                     </div>
                     <div className="flex items-center gap-4 text-white">
                        <div className="p-2 bg-info rounded-full"><CheckCircle2 size={20} /></div>
                        <span className="font-medium">Motivação Constante</span>
                     </div>
                     <div className="flex items-center gap-4 text-white">
                        <div className="p-2 bg-white/20 rounded-full"><CheckCircle2 size={20} /></div>
                        <span className="font-medium">Foco nos Resultados</span>
                     </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 px-6">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-center mb-16">O que dizem os alunos</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Mariana Silva", grade: "11º Ano", text: "O Notaí ajudou-me a perceber exatamente onde precisava de estudar mais. A minha média subiu 2 valores!", stars: 5 },
              { name: "João Santos", grade: "12º Ano", text: "Simples, rápido e bonito. Uso todos os dias depois das aulas para atualizar as minhas notas.", stars: 5 },
              { name: "Beatriz Costa", grade: "10º Ano", text: "Adoro os gráficos! Dá-me muita motivação ver a linha de progresso a subir ao longo do período.", stars: 4 },
            ].map((t, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <div className="flex gap-1 text-yellow-400 mb-4">
                  {[...Array(5)].map((_, idx) => (
                    <Star key={idx} size={16} fill={idx < t.stars ? "currentColor" : "none"} className={idx >= t.stars ? "text-gray-300" : ""} />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center font-bold text-gray-500">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">{t.name}</div>
                    <div className="text-xs text-gray-400 uppercase tracking-wide">{t.grade}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-100 py-12 px-6">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Notaí" className="h-8 w-auto object-contain" />
          </div>
          <div className="flex gap-8 text-sm text-gray-500">
            <a href="#" className="hover:text-primary transition-colors">Política de Privacidade</a>
            <a href="#" className="hover:text-primary transition-colors">Termos de Uso</a>
            <a href="#" className="hover:text-primary transition-colors">Contacto</a>
          </div>
          <div className="text-sm text-gray-400">
            © 2024 Notaí. Todos os direitos reservados.
          </div>
        </div>
      </footer>
    </div>
  );
};