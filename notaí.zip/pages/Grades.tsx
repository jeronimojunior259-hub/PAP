import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Plus, Search, Trash2, Filter } from 'lucide-react';
import { Grade, GradeType } from '../types';

export const Grades = () => {
  const { grades, addGrade, removeGrade } = useApp();
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('All');

  // Form State
  const [subject, setSubject] = useState('');
  const [type, setType] = useState<GradeType>('Teste');
  const [value, setValue] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !value) return;

    addGrade({
      subject,
      type,
      value: parseFloat(value),
      date
    });

    // Reset
    setSubject('');
    setValue('');
    setShowForm(false);
  };

  const filteredGrades = grades.filter(g => {
    const matchesSearch = g.subject.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'All' || g.type === filterType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-3xl font-heading font-bold text-gray-900">As Minhas Notas</h1>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-6 py-3 bg-primary text-white font-medium rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
        >
          <Plus size={20} /> Adicionar Nota
        </button>
      </div>

      {showForm && (
        <div className="bg-white p-6 rounded-3xl border border-primary/20 shadow-lg animate-slide-down">
          <h3 className="text-lg font-bold mb-4">Nova Avaliação</h3>
          <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <input
              type="text"
              placeholder="Disciplina (ex: Matemática)"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              required
            />
            <select
              value={type}
              onChange={(e) => setType(e.target.value as GradeType)}
              className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
            >
              <option value="Teste">Teste</option>
              <option value="Trabalho">Trabalho</option>
              <option value="Exame">Exame</option>
              <option value="Oral">Oral</option>
            </select>
            <input
              type="number"
              placeholder="Nota (0-20)"
              min="0"
              max="20"
              step="0.1"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className="px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
              required
            />
            <div className="flex gap-2">
               <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
                required
              />
              <button type="submit" className="px-6 py-3 bg-secondary text-white rounded-xl hover:bg-green-500 font-medium">Guardar</button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-3.5 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Pesquisar por disciplina..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary"
          />
        </div>
        <div className="relative w-full md:w-48">
          <Filter className="absolute left-4 top-3.5 text-gray-400 w-5 h-5" />
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary appearance-none"
          >
            <option value="All">Todos os tipos</option>
            <option value="Teste">Teste</option>
            <option value="Trabalho">Trabalho</option>
            <option value="Exame">Exame</option>
            <option value="Oral">Oral</option>
          </select>
        </div>
      </div>

      {/* List */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-gray-50/50 border-b border-gray-100 text-gray-500 text-sm uppercase tracking-wider">
                <th className="px-6 py-4 font-semibold">Disciplina</th>
                <th className="px-6 py-4 font-semibold">Tipo</th>
                <th className="px-6 py-4 font-semibold">Data</th>
                <th className="px-6 py-4 font-semibold">Nota</th>
                <th className="px-6 py-4 font-semibold text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredGrades.length > 0 ? (
                filteredGrades.map((grade) => (
                  <tr key={grade.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-gray-900">{grade.subject}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium 
                        ${grade.type === 'Teste' ? 'bg-purple-50 text-purple-700' : 
                          grade.type === 'Exame' ? 'bg-red-50 text-red-700' : 
                          'bg-blue-50 text-blue-700'}`}>
                        {grade.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-500">{new Date(grade.date).toLocaleDateString()}</td>
                    <td className="px-6 py-4 font-bold text-gray-900">{grade.value}</td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => removeGrade(grade.id)}
                        className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-400">
                    Nenhuma nota encontrada.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
