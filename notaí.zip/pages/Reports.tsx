import React from 'react';
import { useApp } from '../contexts/AppContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { Download } from 'lucide-react';

export const Reports = () => {
  const { grades } = useApp();

  // Prepare Data for Subject Averages
  const subjectAverages = React.useMemo(() => {
    const bySubject: Record<string, number[]> = {};
    grades.forEach(g => {
      if (!bySubject[g.subject]) bySubject[g.subject] = [];
      bySubject[g.subject].push(g.value);
    });

    return Object.entries(bySubject).map(([subject, values]) => ({
      name: subject,
      average: Number((values.reduce((a, b) => a + b, 0) / values.length).toFixed(1))
    })).sort((a, b) => b.average - a.average);
  }, [grades]);

  // Distribution Data
  const distributionData = React.useMemo(() => {
    let ranges = [
      { name: '0-9 (Negativa)', value: 0, color: '#EF4444' },
      { name: '10-13 (Suficiente)', value: 0, color: '#FCD34D' },
      { name: '14-17 (Bom)', value: 0, color: '#66BB6A' },
      { name: '18-20 (Excelente)', value: 0, color: '#673AB7' },
    ];

    grades.forEach(g => {
      if (g.value < 10) ranges[0].value++;
      else if (g.value < 14) ranges[1].value++;
      else if (g.value < 18) ranges[2].value++;
      else ranges[3].value++;
    });

    return ranges.filter(r => r.value > 0);
  }, [grades]);

  const handleExport = () => {
    // Simple mock export
    alert("Funcionalidade de exportação: O PDF com o teu relatório está a ser gerado!");
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-3xl font-heading font-bold text-gray-900">Relatórios</h1>
        <div className="flex gap-2">
            <button
            onClick={handleExport}
            className="px-6 py-3 bg-white border border-gray-200 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
            >
            <Download size={20} /> Exportar PDF
            </button>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Bar Chart: Averages per Subject */}
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-xl font-heading font-bold text-gray-800 mb-6">Média por Disciplina</h3>
          <div className="h-[300px] w-full">
            {subjectAverages.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectAverages} layout="vertical" margin={{ left: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f0f0f0" />
                  <XAxis type="number" domain={[0, 20]} hide />
                  <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 12, fill: '#4B5563' }} />
                  <Tooltip 
                    cursor={{fill: 'transparent'}}
                    contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                  />
                  <Bar dataKey="average" radius={[0, 4, 4, 0]} barSize={20}>
                    {subjectAverages.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.average >= 10 ? '#66BB6A' : '#EF4444'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
               <div className="h-full flex items-center justify-center text-gray-400">Sem dados suficientes.</div>
            )}
          </div>
        </div>

        {/* Pie Chart: Distribution */}
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-xl font-heading font-bold text-gray-800 mb-6">Distribuição de Notas</h3>
          <div className="h-[300px] w-full">
            {distributionData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={distributionData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {distributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}} />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
            ) : (
                <div className="h-full flex items-center justify-center text-gray-400">Sem dados suficientes.</div>
            )}
          </div>
        </div>
      </div>
      
      {/* Summary Table */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-100">
              <h3 className="text-xl font-heading font-bold text-gray-800">Resumo Detalhado</h3>
          </div>
          <div className="overflow-x-auto">
             <table className="w-full text-left">
                <thead>
                    <tr className="bg-gray-50 text-gray-500 text-xs uppercase">
                        <th className="px-6 py-4">Disciplina</th>
                        <th className="px-6 py-4 text-center">Média</th>
                        <th className="px-6 py-4 text-center">Status</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {subjectAverages.map((sub, i) => (
                        <tr key={i}>
                            <td className="px-6 py-4 font-medium text-gray-900">{sub.name}</td>
                            <td className="px-6 py-4 text-center font-bold text-lg">{sub.average}</td>
                            <td className="px-6 py-4 text-center">
                                <span className={`px-3 py-1 rounded-full text-xs font-bold ${sub.average >= 10 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                    {sub.average >= 10 ? 'Aprovado' : 'Em Risco'}
                                </span>
                            </td>
                        </tr>
                    ))}
                </tbody>
             </table>
          </div>
      </div>
    </div>
  );
};
