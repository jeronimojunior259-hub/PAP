import React, { useState } from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useApp } from '../contexts/AppContext';
import { Mail, Lock, User as UserIcon, ArrowRight } from 'lucide-react';

export const Auth = () => {
  const { login, isAuthenticated } = useApp();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login for demo
    if (email && password) {
      login(email, isLogin ? 'Estudante' : name);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <Link to="/" className="inline-flex items-center justify-center mb-6 group">
            <img 
              src="/logo.png" 
              alt="Notaí" 
              className="h-20 w-auto object-contain group-hover:scale-105 transition-transform" 
            />
          </Link>
          <h2 className="text-3xl font-heading font-bold text-gray-900 mb-2">
            {isLogin ? 'Bem-vindo de volta!' : 'Cria a tua conta'}
          </h2>
          <p className="text-gray-500">
            {isLogin ? 'Entra para veres a tua evolução.' : 'Começa hoje a gerir o teu sucesso escolar.'}
          </p>
        </div>

        <div className="bg-white rounded-[2rem] shadow-xl shadow-gray-200/50 p-8 border border-gray-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700 ml-1">Nome Completo</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-3.5 text-gray-400 w-5 h-5" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                    placeholder="O teu nome"
                    required={!isLogin}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 ml-1">Email</label>
              <div className="relative">
                <Mail className="absolute left-4 top-3.5 text-gray-400 w-5 h-5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                  placeholder="exemplo@escola.pt"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center ml-1">
                <label className="text-sm font-medium text-gray-700">Palavra-passe</label>
                {isLogin && <a href="#" className="text-xs text-primary font-medium hover:underline">Esqueci-me</a>}
              </div>
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 text-gray-400 w-5 h-5" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-gray-100 rounded-xl focus:bg-white focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 bg-primary text-white font-bold rounded-xl shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2"
            >
              {isLogin ? 'Entrar' : 'Criar Conta Grátis'} <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500">
              {isLogin ? 'Ainda não tens conta?' : 'Já tens conta?'}
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="ml-2 text-primary font-semibold hover:underline"
              >
                {isLogin ? 'Regista-te' : 'Faz Login'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};