import React, { useMemo } from 'react';
import { useApp } from '../contexts/AppContext';
import { TrendingUp, TrendingDown, BookOpen, Calculator, Award } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export const Dashboard = () => {
  const { user, grades } = useApp();

  // Statistics Calculation
  const stats = useMemo(() => {
    if (grades.length === 0) return { average: 0, bestSubject: '-', worstSubject: '-', totalGrades: 0 };

    const total = grades.reduce((acc, curr) => acc + curr.value, 0);
    const average = total / grades.length;

    // Group by subject
    const bySubject: Record<string, number[]> = {};
    grades.forEach(g => {
      if (!bySubject[g.subject]) bySubject[g.subject] = [];
      bySubject[g.subject].push(g.value);
    });

    let bestSub = { name: '-', avg: -1 };
    let worstSub = { name: '-', avg: 21 };

    Object.entries(bySubject).forEach(([subject, values]) => {
      const avg = values.reduce((a, b) => a + b, 0) / values.length;
      if (avg > bestSub.avg) bestSub = { name: subject, avg };
      if (avg < worstSub.avg) worstSub = { name: subject, avg };
    });

    return {
      average: average.toFixed(1),
      bestSubject: bestSub.name,
      worstSubject: worstSub.name,
      totalGrades: grades.length
    };
  }, [grades]);

  const recentGrades = [...grades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 3);

  // Chart Data: Evolution over time
  const chartData = useMemo(() => {
    return [...grades]
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map(g => ({
        date: new Date(g.date).toLocaleDateString('pt-PT', { day: '2-digit', month: 'short' }),
        value: g.value,
        subject: g.subject
      }));
  }, [grades]);

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-heading font-bold text-gray-900">Olá, {user?.name.split(' ')[0]} 👋</h1>
          <p className="text-gray-500">Aqui está o resumo da tua performance escolar.</p>
        </div>
        <div className="px-4 py-2 bg-white rounded-full border border-gray-200 text-sm font-medium text-gray-600 shadow-sm">
          Ano Letivo: {user?.schoolYear}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col justify-between h-40 relative overflow-hidden group hover:shadow-md transition-shadow">
          <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-bl-[4rem] transition-transform group-hover:scale-110"></div>
          <div>
            <div className="text-gray-500 text-sm font-medium mb-1">Média Geral</div>
            <div className="text-4xl font-bold text-primary">{stats.average}</div>
          </div>
          <div className="flex items-center gap-2 text-sm text-secondary font-medium">
             <Calculator size={16} /> <span>Calculado automaticamente</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col justify-between h-40 hover:shadow-md transition-shadow">
          <div>
            <div className="text-gray-500 text-sm font-medium mb-1">Melhor Disciplina</div>
            <div className="text-xl font-bold text-gray-900 truncate" title={stats.bestSubject}>{stats.bestSubject}</div>
          </div>
          <div className="w-10 h-10 bg-green-50 text-secondary rounded-xl flex items-center justify-center">
            <TrendingUp size={20} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col justify-between h-40 hover:shadow-md transition-shadow">
          <div>
            <div className="text-gray-500 text-sm font-medium mb-1">A Melhorar</div>
            <div className="text-xl font-bold text-gray-900 truncate" title={stats.worstSubject}>{stats.worstSubject}</div>
          </div>
          <div className="w-10 h-10 bg-orange-50 text-orange-400 rounded-xl flex items-center justify-center">
            <TrendingDown size={20} />
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col justify-between h-40 hover:shadow-md transition-shadow">
          <div>
            <div className="text-gray-500 text-sm font-medium mb-1">Total de Avaliações</div>
            <div className="text-4xl font-bold text-gray-900">{stats.totalGrades}</div>
          </div>
          <div className="w-10 h-10 bg-blue-50 text-info rounded-xl flex items-center justify-center">
            <BookOpen size={20} />
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-heading font-bold text-gray-800">Evolução Recente</h3>
            <span className="text-sm text-gray-400">Últimas avaliações</span>
          </div>
          <div className="h-[300px] w-full">
            {chartData.length > 1 ? (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#673AB7" stopOpacity={0.2}/>
                      <stop offset="95%" stopColor="#673AB7" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#9CA3AF', fontSize: 12}} />
                  <YAxis domain={[0, 20]} axisLine={false} tickLine={false} tick={{fill: '#9CA3AF', fontSize: 12}} />
                  <Tooltip 
                    contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                    labelStyle={{color: '#9CA3AF', marginBottom: '4px'}}
                  />
                  <Area type="monotone" dataKey="value" stroke="#673AB7" strokeWidth={3} fillOpacity={1} fill="url(#colorValue)" />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-gray-400">
                Adiciona mais notas para ver o gráfico.
              </div>
            )}
          </div>
        </div>

        {/* Recent Grades List */}
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-heading font-bold text-gray-800">Últimas Notas</h3>
          </div>
          <div className="space-y-4">
            {recentGrades.length > 0 ? (
              recentGrades.map((grade) => (
                <div key={grade.id} className="flex items-center justify-between p-4 rounded-2xl bg-gray-50 hover:bg-white hover:shadow-md transition-all border border-transparent hover:border-gray-100">
                  <div className="flex items-center gap-4">
                    <div className={`w-2 h-12 rounded-full ${grade.value >= 10 ? 'bg-secondary' : 'bg-red-400'}`}></div>
                    <div>
                      <div className="font-bold text-gray-900">{grade.subject}</div>
                      <div className="text-xs text-gray-500 uppercase tracking-wide">{grade.type} • {new Date(grade.date).toLocaleDateString()}</div>
                    </div>
                  </div>
                  <div className="text-lg font-bold text-primary">{grade.value}</div>
                </div>
              ))
            ) : (
              <div className="text-center text-gray-400 py-8">
                Ainda não tens notas registadas.
              </div>
            )}
            
            {recentGrades.length > 0 && (
              <button className="w-full mt-4 py-3 text-sm text-primary font-medium hover:bg-primary/5 rounded-xl transition-colors">
                Ver todo o histórico
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
