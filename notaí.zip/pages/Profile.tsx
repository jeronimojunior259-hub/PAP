import React from 'react';
import { useApp } from '../contexts/AppContext';
import { User, Mail, School, PenSquare } from 'lucide-react';

export const Profile = () => {
  const { user } = useApp();

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <h1 className="text-3xl font-heading font-bold text-gray-900 mb-8">O Meu Perfil</h1>

      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-primary to-purple-400"></div>
        <div className="px-8 pb-8">
          <div className="relative -mt-16 mb-6 flex justify-between items-end">
            <div className="w-32 h-32 rounded-full border-4 border-white bg-gray-200 shadow-md overflow-hidden">
              <img src={user?.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <button className="px-4 py-2 bg-gray-100 text-gray-700 font-medium rounded-xl hover:bg-gray-200 transition-colors flex items-center gap-2 text-sm">
              <PenSquare size={16} /> Editar
            </button>
          </div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900">{user?.name}</h2>
            <p className="text-gray-500">Aluno</p>
          </div>

          <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 border border-gray-100">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-primary shadow-sm">
                <Mail size={20} />
              </div>
              <div>
                <div className="text-xs text-gray-500 uppercase font-bold tracking-wide">Email</div>
                <div className="text-gray-900 font-medium">{user?.email}</div>
              </div>
            </div>

            <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 border border-gray-100">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-primary shadow-sm">
                <School size={20} />
              </div>
              <div>
                <div className="text-xs text-gray-500 uppercase font-bold tracking-wide">Ano Escolar</div>
                <div className="text-gray-900 font-medium">{user?.schoolYear}</div>
              </div>
            </div>

             <div className="flex items-center gap-4 p-4 rounded-2xl bg-gray-50 border border-gray-100">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-primary shadow-sm">
                <User size={20} />
              </div>
              <div>
                <div className="text-xs text-gray-500 uppercase font-bold tracking-wide">ID de Aluno</div>
                <div className="text-gray-900 font-medium text-sm font-mono">{user?.id}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
